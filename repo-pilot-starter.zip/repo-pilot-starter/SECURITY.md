# Security Policy

## Reporting a Vulnerability
Please report security issues privately via GitHub Security advisories or email the maintainer.
We will coordinate a fix and disclosure timeline.

## Supported Versions
Security updates are applied to the default branch.
